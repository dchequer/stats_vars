
# Stats Vars
This is an extensive project that aims to provide a large library of statistical analysis variables/methods